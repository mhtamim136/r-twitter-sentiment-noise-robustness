# ----------------------------------------------------------------------
# Regenerates the two figures added in v6:
#
#   figures/fig_cv_v6.png  - per-fold cross-validation accuracy (Fig. 6)
#   figures/fig_cm_v6.png  - confusion matrix heat map          (Fig. 5)
#
# Run from the paper folder (the one containing main.tex).
#
# Why these are re-rendered rather than reused from paper_outputs/:
#
#   fig_cv_perfold.png is 9 x 4.5 in with the two panels side by side.
#   Dropped into a 3.45 in IEEE column that scales the axis text to under
#   5 pt, which is below the 8 pt floor IEEE sets for figure text, and
#   promoting it to a full-width figure* would cost twice its height in
#   column space. This version is drawn at column width from the start.
#
#   fig_confusion_matrix.png carries its own title and subtitle inside
#   the image. In an IEEE paper the caption does that job, so the title
#   would appear twice. The colour bar is also redundant once every cell
#   is labelled with its count, and dropping it hands about a fifth of
#   the width back to the matrix itself.
#
# Both figures are built from literals below rather than from .RData, so
# they cannot drift from the numbers printed in Tables IV and VI.
# ----------------------------------------------------------------------

suppressPackageStartupMessages(library(ggplot2))

DIR      <- "figures/"
BASELINE <- 0.3026        # majority-class rate, Negative = 1,514 / 5,002
MODELCOL <- c("Naive Bayes" = "#4DAF4A", "SVM" = "#8DB6D8",
              "Multinomial LR" = "#EE8371")

# ---- Fig. 6: per-fold cross-validation accuracy (Table VI) ------------

cv <- data.frame(
  Representation = rep(c("BoW", "TF-IDF"), each = 15),
  Model = rep(rep(c("Naive Bayes", "SVM", "Multinomial LR"), each = 5), 2),
  Fold  = rep(1:5, 6),
  Accuracy = c(
    # BoW
    37.04, 37.50, 34.10, 33.30, 35.94,   # Naive Bayes
    45.65, 46.30, 45.90, 44.00, 45.55,   # SVM
    44.54, 48.20, 45.90, 46.40, 45.55,   # Multinomial LR
    # TF-IDF
    32.93, 31.90, 31.00, 29.60, 31.23,   # Naive Bayes
    46.05, 47.10, 46.10, 45.60, 47.45,   # SVM
    47.15, 49.40, 47.30, 46.60, 47.15    # Multinomial LR
  ) / 100
)
cv$Model <- factor(cv$Model, levels = names(MODELCOL))

p_cv <- ggplot(cv, aes(factor(Fold), Accuracy, fill = Model)) +
  geom_col(position = position_dodge(width = 0.8), width = 0.72,
           colour = "grey25", linewidth = 0.15) +
  geom_hline(yintercept = BASELINE, linetype = "dashed",
             colour = "grey20", linewidth = 0.4) +
  facet_wrap(~Representation) +
  scale_fill_manual(values = MODELCOL) +
  scale_y_continuous(limits = c(0, 0.53), breaks = seq(0, 0.5, 0.1),
                     expand = c(0, 0)) +
  labs(x = "Cross-validation fold", y = "Accuracy", fill = NULL) +
  theme_bw(base_size = 8) +
  theme(legend.position = "bottom",
        legend.margin = margin(t = -4),
        legend.key.size = unit(7, "pt"),
        panel.grid.minor = element_blank(),
        strip.background = element_rect(fill = "grey92", colour = "grey40"))

ggsave(paste0(DIR, "fig_cv_v6.png"), p_cv,
       width = 3.45, height = 2.35, dpi = 400, bg = "white")

# ---- Fig. 5: confusion matrix, MLR + BoW, clean test set (Table IV) ---

lev <- c("Irrelevant", "Negative", "Neutral", "Positive")
cm <- data.frame(
  Prediction = factor(rep(lev, each = 4), levels = rev(lev)),
  Reference  = factor(rep(lev, times = 4), levels = lev),
  # rows are predictions, in the order of lev
  Freq = c(48,  18,  18,  25,
           47, 164,  60,  48,
           26,  44, 100,  46,
           53,  76,  69, 156)
)

p_cm <- ggplot(cm, aes(Reference, Prediction, fill = Freq)) +
  geom_tile(colour = "white", linewidth = 0.8) +
  geom_text(aes(label = Freq, fontface = ifelse(
    as.character(Reference) == as.character(Prediction), "bold", "plain")),
    size = 3.1, colour = "grey10") +
  scale_fill_gradient(low = "white", high = "#4A7FB5", guide = "none") +
  scale_x_discrete(position = "top", expand = c(0, 0)) +
  scale_y_discrete(expand = c(0, 0)) +
  labs(x = "True label", y = "Predicted label") +
  theme_minimal(base_size = 8) +
  theme(panel.grid = element_blank(),
        axis.text = element_text(colour = "grey15"),
        axis.title = element_text(colour = "grey15"),
        plot.margin = margin(2, 2, 2, 2))

# No coord_fixed(): letting the cells run wider than tall costs nothing in
# readability and takes about 35 pt of column height off the figure.
ggsave(paste0(DIR, "fig_cm_v6.png"), p_cm,
       width = 3.40, height = 2.30, dpi = 400, bg = "white")

# ---- sanity checks ---------------------------------------------------

cat("diagonal =", sum(cm$Freq[as.character(cm$Prediction) ==
                              as.character(cm$Reference)]),
    "of", sum(cm$Freq), "->",
    sprintf("%.1f%% accuracy\n",
            100 * sum(cm$Freq[as.character(cm$Prediction) ==
                              as.character(cm$Reference)]) / sum(cm$Freq)))
cat("row totals (predictions):", tapply(cm$Freq, cm$Prediction, sum), "\n")
cat("col totals (true labels):", tapply(cm$Freq, cm$Reference, sum), "\n")
cat("folds below baseline:",
    with(cv, paste(Representation[Accuracy < BASELINE],
                   Model[Accuracy < BASELINE],
                   paste0("fold ", Fold[Accuracy < BASELINE]),
                   collapse = "; ")), "\n")
for (f in unique(cv$Fold)) for (r in unique(cv$Representation)) {
  s <- cv[cv$Fold == f & cv$Representation == r, ]
  cat(sprintf("  %-6s fold %d ordering: %s\n", r, f,
              paste(as.character(s$Model[order(-s$Accuracy)]), collapse = " > ")))
}
cat("\nwrote", paste0(DIR, "fig_cv_v6.png"), "and", paste0(DIR, "fig_cm_v6.png"), "\n")
