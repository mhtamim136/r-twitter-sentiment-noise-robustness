========================================================================
IEEE CONFERENCE PAPER  -  VERSION 6  (FINAL)
(three figures added, word cloud swapped, two emails fixed,
 two numeric claims corrected, Section V shortened to kill page 8)
Introduction to Data Science (00677), Spring 2025-2026
American International University-Bangladesh
========================================================================

Title : Classifier Choice Outweighs Representation Choice for
        Noise-Robust Twitter Sentiment Classification

Authors printed on the paper:
  Md. Murad Hasan*      23-55559-3@student.aiub.edu   <- fixed in v6
  Mahbuba Nasrin        23-54976-3@student.aiub.edu
  Najiat Islam Rishad   23-55218-3@student.aiub.edu
  Atia Chowdhury        23-52252-2@student.aiub.edu   <- fixed in v6
  Kamrun Naher Koli     kkoli@aiub.edu

Parts 1 to 10 of this file describe v5 and are still accurate. Part 0
below is the v6 change list. If you only read one thing, read part 0.6 -
while building the new cross-validation figure I found two numeric
claims in the paper that were wrong, and both are now fixed.


------------------------------------------------------------------------
0. WHAT CHANGED IN v6
------------------------------------------------------------------------

0.1  THE TWO EMAIL ADDRESSES

  Md. Murad Hasan   23-55559@student.aiub.edu   -> 23-55559-3@...
  Atia Chowdhury    23-52252-1@student.aiub.edu -> 23-52252-2@...

Nothing else in the author block was touched.


0.2  THE WORD CLOUD IS NOW YOUR IMAGE

Fig. 2 now uses figures/fig_wordcloud_v6.png, which is the image you
put in "New folder" (fig_wordcloud_v5_masked.png), cropped.

The crop was necessary, not cosmetic: 51.2% of that PNG's pixel area
was dead white margin, mostly down the left and right sides. Left
uncropped, LaTeX scales the whole canvas to fit the 0.78\linewidth box,
so the words come out about 30% smaller than they need to be. After
cropping, 1400x1000 px becomes 887x771 px, all 24 words are intact,
and the figure renders 4 pt SHORTER than the v5 word cloud did - so
this swap cost nothing in page length.

The caption changed by one sentence. Your version removes the two
profane terms rather than masking them, and puts "work" and "thank" in
their place. Those two terms are ranked 6th (309 occurrences) and 20th
(193) in the 177-term vocabulary, so the figure is no longer literally
"the 24 most frequent terms". The caption now says so:

  "...Two profane terms, ranked sixth and twentieth, are withheld from
  the display but remain in the feature space the classifiers were
  given..."

That sentence matters. Without it a reviewer who recomputes the term
frequencies finds two terms missing and has to decide whether the
figure is wrong or the vocabulary is. Section IV-A's claim that "only
Negative and Positive carry sentiment-bearing terms among their most
frequent words" is a PER-CLASS claim taken from the per-class top-5
output, not from this figure, so it is unaffected.

My own asterisk-masked version is still in figures/ as
fig_wordcloud_v5_masked.png if you ever want it back.


0.3  THREE FIGURES ADDED (this is the bulk of v6)

You asked which of the dropped figures were worth restoring, where
they belong, and which ones the paper genuinely needs. Here is the
ranking I arrived at, and the reasoning.

  Fig. 4  fig_d_clean_vs_noisy.png   -> Section IV-C
  Fig. 5  fig_cm_v6.png              -> Section IV-D
  Fig. 6  fig_cv_v6.png              -> Section IV-E

RANK 1 - clean vs. noisy accuracy, Section IV-C.
This one is not decoration. Section IV-C is where the paper's title
claim lives, and it was the only subsection in Section IV with no
float of its own. The figure makes the claim visible in a way no table
can: the BoW panel and the TF-IDF panel are near-copies of each other
(representation barely matters) while inside each panel the Naive
Bayes pair sits in a band well below the other two (classifier matters
a lot). You cannot see "these two panels look alike" in a column of
numbers. The dashed baseline also shows that exactly one bar in the
whole figure falls below the majority-class rate.

RANK 2 - per-fold cross-validation, Section IV-E.
Section IV-E argues that the classifier gap is an order of magnitude
larger than the fold-to-fold spread. That is an argument about the
relative size of two variations, and Table VI asks the reader to hold
thirty numbers in their head to see it. As bars it is immediate: the
green bar is shortest in all ten fold-by-representation cells, the
blue and salmon bars are close enough to swap order, and TF-IDF fold 4
is the one bar that crosses under the baseline.

RANK 3 - confusion matrix heat map, Section IV-D.
The weakest of the three on paper, because Table IV already IS this
matrix, cell for cell. I kept it because the shading carries something
the digits do not: the error mass is gathered into TWO prediction rows
(Negative 319 and Positive 354, 673 of 998 tweets between them), each
drawing at least 47 cases from every true class, while the Irrelevant
row stays pale across its whole width. That is a statement about the
shape of the errors, and it is what the new paragraph in IV-D says.
Table IV is kept as well, because it carries the row and column totals
that IV-D's prose quotes (109 predictions for 174 true Irrelevant
tweets, 354 for 275 true Positive) and the heat map does not.

Each of the three has a new explanatory paragraph next to it in the
body text - not a restatement of the caption, but the specific thing
the figure shows that its table does not.

WHAT I DID NOT PUT BACK, AND WHY
  fig_a_class_distribution.png  Four bars. Table II already gives the
                                same four counts and percentages.
  fig_f_bubble.png              Both axes are columns of Table III.
  fig_b_length_hist.png         Tweet length. Section IV-A says
  fig_c_length_by_class.png     explicitly that length was NOT used as
                                a feature, so a figure about it invites
                                the question "then why show it?"
  fig_g_cv_perfold.png          Superseded by fig_cv_v6.png, below.
  fig_confusion_matrix.png      Superseded by fig_cm_v6.png, below.


0.4  WHY TWO OF THE THREE WERE RE-RENDERED (mkfigs_v6.R)

fig_d_clean_vs_noisy.png is used exactly as your R run produced it.
The other two were redrawn, and the script that does it is included.

  paper_outputs/fig_cv_perfold.png is 9.0 x 4.5 in with the two panels
  side by side. Dropped into a 3.45 in IEEE column that scales the axis
  text to under 5 pt. IEEE's floor for text inside a figure is 8 pt, so
  that is a format violation, not just an ugly figure. Promoting it to
  a full-width figure* would have been legal but costs TWICE its height
  in column space (see part 5 for why). fig_cv_v6.png is drawn at 3.45
  in from the start with base_size = 8, so nothing is scaled down.

  paper_outputs/fig_confusion_matrix.png carries its own title and
  subtitle inside the image. In an IEEE paper the caption does that
  job, so the title would have appeared twice. Its colour bar is also
  redundant once every cell is labelled with its count, and removing it
  hands about a fifth of the width back to the matrix. fig_cm_v6.png
  drops both, bolds the diagonal, and is 35 pt shorter as a result.

Both are built from LITERALS in mkfigs_v6.R, copied from Tables IV and
VI, not from .RData. That is deliberate: the figures cannot drift from
the numbers printed in the paper. The script prints its own sanity
checks when you run it - diagonal 468 of 998 = 46.9% accuracy, row
totals 109/319/216/354, column totals 174/302/247/275, and one fold
below baseline (TF-IDF, Naive Bayes, fold 4). Those all match the
tables.


0.5  ONE PREAMBLE CHANGE

  \setcounter{topnumber}{2}   -> 3
  \setcounter{totalnumber}{3} -> 4

Section IV now carries twelve floats. With only three allowed per page
LaTeX starts deferring them, and a deferred backlog eventually comes
out as a float-only page, which wastes more space than a densely
packed column does. Raising the limit lets it pack.


0.6  TWO NUMERIC CLAIMS WERE WRONG - BOTH NOW FIXED

I found these while writing the sanity checks into mkfigs_v6.R. Neither
was introduced in v6; both have been in the paper since v3 or earlier.

  (a) "the ordering of the three classifiers is identical in all five
      folds of both representations"   -- Section IV-C, was FALSE.

      SVM and MLR swap places. MLR is ahead in 6 of the 10
      fold-by-representation cells, SVM in 2, and they are tied to two
      decimal places in 2 (BoW folds 3 and 5, both 45.90 and 45.55).

      What IS true in all ten cells is that Naive Bayes finishes last,
      behind whichever discriminative model is nearer by between 7.5
      and 16.0 points. That is the claim the paper actually needs, and
      it is stronger than the one it had. Now written as:

        "...and it finishes last in all ten fold-by-representation
        cells of Table VI, behind whichever of the two discriminative
        models is nearer by between 7.5 and 16.0 points."

  (b) "BoW and TF-IDF never differed by more than 1.4 points for the
      same classifier"  -- ABSTRACT, Section IV-C and CONCLUSION, was
      FALSE for Naive Bayes.

      The same-classifier representation gaps are:
        SVM     1.1 clean, 0.3 noisy, 0.98 CV mean
        MLR     1.3 clean, 0.1 noisy, 1.40 CV mean
        NB      4.0 clean, 6.2 noisy, 4.24 CV mean   <- not <= 1.4

      The 1.4-point bound holds for the two discriminative classifiers
      only. All three places are now scoped to say so, and Section IV-C
      names the exception explicitly rather than letting a reader find
      it in Table II:

        "Naive Bayes is the exception, and the only one: BoW leads
        TF-IDF for it by 4.0 points on clean data, 6.2 under noise, and
        4.2 on the cross-validated mean. That does not disturb the
        ranking, since Naive Bayes finishes behind both discriminative
        models either way."

      This does not weaken the paper. The largest effect a
      representation has on any classifier is still smaller than the
      smallest classifier gap in any fold, and the exception lands on
      the one classifier the paper already recommends against.

  (c) Minor, same family: Section IV-F said Al Sarayrah's Naive Bayes
      variants trailed the RBF SVM "by seven to eight points". The real
      gaps are 7.2 and 8.4, and Related Work already said so. IV-F now
      matches.


0.7  THE 7-PAGE BUDGET, AND THE ONE TRIM THAT CLOSED IT

You said v5 came out at 6 pages plus a short spill onto 7, and that 7
is acceptable as long as it does not become 8. The figures and prose
added above cost:

  Fig. 4  fig_d_clean_vs_noisy   207 pt tall  ->  229 col-pt
  Fig. 5  fig_cm_v6              168 pt tall  ->  190 col-pt
  Fig. 6  fig_cv_v6              169 pt tall  ->  191 col-pt
  Fig. 2  word-cloud swap        168 pt tall  ->   -3 col-pt
  new prose, +318 words measured               ->  393 col-pt
                                                  ----------
                                        TOTAL     1000 col-pt

You then compiled it and sent the PDF back. It came out at 7 pages
plus one item on page 8: reference [23], Dietterich, four lines of
\footnotesize text occupying y 52.9 to 87.7, so 34.8 pt. Both columns
of page 7 ended flush at y 718.4, i.e. completely full. So the whole
overflow was 34.8 pt of column height and nothing more.

Rather than drop a figure for 35 pt, Section V was shortened, which is
what you asked for anyway. Two paragraphs were rewritten; nothing else
in the document changed (verified by line-by-line diff against the
first v6 build - exactly lines 386 and 390 differ):

  paragraph        words        lines      frees
  ---------------------------------------------------
  summary        188 -> 154   21 -> 17    46.0 pt
  limitations     54 ->  54    6 ->  6     0.0 pt   (left alone, see below)
  future work     85 ->  57   10 ->  7    34.5 pt
  ---------------------------------------------------
  TOTAL          327 -> 265               80.5 pt

80.5 pt freed against 34.8 pt needed leaves 45.7 pt, about four body
lines, of slack. The line estimate is not guesswork: the old future-work
paragraph measured 85 words in 9 lines in your PDF, so 9.4 words per
line, and 105.6 pt over 9 lines, so 11.7 pt of leading. Those are the
constants used above.

What came out of the summary paragraph:
  - "the two discriminative classifiers consistently outperformed
    Naive Bayes on both clean and corrupted text" - the priority
    sentence two lines later says the same thing with numbers.
  - the clean-data p=0.061 result. It is still in the abstract and in
    Section IV-B, line 235, so nothing was orphaned; the conclusion now
    carries only the sharper of the two statistics, kappa=0.046.

What came out of future work: hyperparameter tuning, extending to the
full cleaned corpus, and adding neural baselines. All three were
generic - they could appear at the end of any paper. What is left are
the two next steps specific to this study (refit the vocabulary and idf
on the training split, swap Gaussian for multinomial Naive Bayes) plus
separating the three noise types. Neural models are still discussed in
Section IV-F, so that thread is not lost from the paper.

THE LIMITATIONS PARAGRAPH WAS DELIBERATELY NOT CUT. You asked whether
it was too long. It is 54 words carrying exactly three clauses, and
each one is a disclosure that protects you rather than a weakness that
exposes you: the 177-term vocabulary bounding accuracy, the sparsity
filtering and document frequencies being computed on the full corpus,
and Gaussian instead of multinomial Naive Bayes. A reader who spots any
of the three unaided will trust the rest of the paper less. Six words
could be shaved off the wording, which is half a line, and that is not
worth the risk of looking like something was tidied away.

  IF SOME LATER EDIT PUSHES IT BACK TO 8 PAGES, comment out ONE figure
  block in main.tex - the confusion-matrix one, around line 340:

    %\begin{figure}[!t]
    %\centering
    %\includegraphics[width=\linewidth]{figures/fig_cm_v6.png}
    %\caption{The confusion matrix of Table \ref{tab:cm} ...}
    %\label{fig:cm}
    %\end{figure}

  and delete the paragraph in Section IV-D that begins
  "Fig.~\ref{fig:cm} shades the same counts". That is 190 + about 90
  col-pt, and it is the right one to drop because it is the only one of
  the three that duplicates a table. Nothing else references fig:cm, so
  no other edit is needed.

  Do NOT drop Fig. 4 or Fig. 6 first. Those two are the ones carrying
  arguments that their tables cannot make.


------------------------------------------------------------------------
1. PACKAGE CONTENTS
------------------------------------------------------------------------
main.tex          The full paper (IEEEtran, conference class)
references.bib    23 references, R1-R23
figures/          14 PNG files: 5 used, 9 spare (see part 8 and 0.3)
data/             The 4 CSV files from your R run (source of Tables II-VI)
mkwordcloud.R     Regenerates Fig. 2 from your .RData (part 4)
mkfigs_v6.R       Regenerates Figs. 5 and 6 (part 0.4)
README.txt        This file

Fig. 1 is drawn in TikZ inside main.tex, so it has no PNG.
Fig. 3 and Fig. 4 are used exactly as your R run produced them.



------------------------------------------------------------------------
2. HOW TO COMPILE (Overleaf)
------------------------------------------------------------------------
 1. overleaf.com -> New Project -> Upload Project -> upload this ZIP.
 2. Open main.tex. Menu -> Compiler -> pdfLaTeX.
 3. Recompile TWICE so BibTeX fills in the [1]..[23] numbers.

Locally: pdflatex main / bibtex main / pdflatex main / pdflatex main

NOTE, PLEASE READ: there is still no LaTeX distribution on the machine
where this was written, so v5 was NOT compiled here. It was checked
programmatically - environment balance, brace balance, every \ref
resolves to a \label, every \label is referenced, every \cite resolves
to a bib key, every \includegraphics file present, the column count and
the measured width of all six tables - and all of that is clean. But the
page count in part 5 is an arithmetic prediction from the v4 PDF, not an
observed fact. Compile it and check.


------------------------------------------------------------------------
3. FACTUAL CORRECTIONS  (the most important part of v5)
------------------------------------------------------------------------
While re-checking the Related Work citations against the actual papers,
two claims in v4 turned out to be wrong. Both were about other authors'
results, which is the worst kind of error to leave in.

(A) ZHANG [12] - v4 misattributed the baseline, the metric, and the cause

    v4 said:
      "Zhang lifted a TF-IDF plus Naive Bayes baseline from 84.43% to
       95.12% precision through further feature engineering, indicating
       clear headroom in that pairing"

    What Zhang's paper actually says:
      - 84.43% is the SVM + TF-IDF baseline, NOT Naive Bayes + TF-IDF.
        (Zhang's Naive Bayes + Word2vec figure is 52.31%, a different
        thing entirely.)
      - The paper labels the 84.43/95.12 pair "precision" in the
        abstract but "accuracy" in the results and in the comparative
        analysis. Two of the three mentions say accuracy.
      - The 95.12% comes from a hybrid that adds BERT-guided feature
        selection, so calling it "further feature engineering" hides
        that a transformer is doing part of the work. The purely
        feature-engineering gains in that paper are reported on a
        macro-F1 axis (0.851 -> 0.902), a different scale.

    v5 says:
      "Zhang reported 95.12% for a Naive Bayes classifier once TF-IDF
       was augmented with domain n-grams and BERT-guided feature
       selection, against 84.43% for an SVM plus TF-IDF baseline, which
       suggests that the weakness of Naive Bayes is tied to the feature
       space it is given rather than being intrinsic to the model
       family."

    This is not just safer, it is a better fit for your argument. Your
    own limitation is that a 177-term vocabulary caps accuracy; Zhang is
    now evidence for exactly that point instead of a vague gesture at
    "headroom". Table I's Zhang row was rewritten to match.

(B) AL SARAYRAH [13] - "seven to eight points" needed a reference point

    v4 said "with both Naive Bayes variants some seven to eight points
    behind", without saying behind what. The real gaps are 8.4 points
    (multinomial NB, 80.21%) and 7.2 points (complement NB, 81.44%)
    BELOW THE RBF SVM at 88.64%. Measured against their LINEAR SVM
    (84.28%) the gaps are only 4.1 and 2.8, so the sentence was true
    only under one reading and 8.4 is not "seven to eight" anyway.
    v5 states the comparator and the exact gaps. Same fix applied in
    Table I and in Section IV-F.

Everything else in Related Work was re-verified against the sources and
is correct as written. Specifically confirmed this round:
  - Srikanth [11]: the abstract does use a TF-IDF vectorizer with
    BernoulliNB, LinearSVC and Logistic Regression, and does say "The
    Logistic Regression model stands out". Your sentence is accurate.
  - Al Sarayrah [13]: RBF SVM 88.64% and BiLSTM 87.72% are exact.
  - Reusens [21]: 20 datasets, 11 classifiers, five tasks, and TF-IDF
    with an SVM among the best overall. Your sentence understates it
    slightly, which is the safe direction.
  - Belinkov & Bisk [8], Moradi & Samwald [9], Aliakbarzadeh [22]:
    all correctly characterised.


------------------------------------------------------------------------
4. FIGURE 2 WAS REBUILT - IT CONTRADICTED YOUR OWN TEXT
------------------------------------------------------------------------
This was not on anyone's review list. It is a real defect and it is the
change I would defend hardest.

THE PROBLEM
  Your analysis.R built the word cloud with

      wordcloud(corpus, max.words = 80, ...)

  wordcloud() SILENTLY DROPS any word it cannot fit in the device and
  only emits a warning, which scrolls past. In the v4 figure it dropped
  "game" (785 occurrences) and "just" (450) - the 1st and 3rd most
  frequent terms in the corpus. Meanwhile Section IV-A of the paper
  says, in words, that game "is the most frequent term in three of the
  four classes". So the figure was missing the very term the caption's
  argument depends on. A reader who looked at the picture would have
  seen the text contradicted.
  The source PNG also had 54% dead white margin and clipped a word off
  its bottom edge.

THE FIX  (mkwordcloud.R, included in this ZIP)
  1. Built from colSums(bow_matrix) instead of the raw corpus, so the
     figure now shows the 177-term feature space THE CLASSIFIERS
     ACTUALLY SEE. That is also more rigorous: the old figure was
     describing a vocabulary the models never used.
  2. Dropped four junk "terms". tm::removePunctuation does not strip
     the Unicode right single quote U+2019, so four entries in your
     177-term vocabulary are apostrophe fragments - the script prints
     them: '  's  ...  'm. They are excluded from the figure. Note the
     paper's "177 terms" is still correct, because that IS the
     vocabulary the models were trained on, artefacts included.
  3. Wrapped the call so warnings are captured, and the font scale
     steps down until ZERO words are dropped. All 24 are placed.
  4. Padded each label with spaces. wordcloud() packs words flush
     against each other, so "just" and "get" rendered as "justget".
     Padding makes the layout engine reserve a gap.
  5. set.seed(42) so the layout is reproducible.
  6. Cropped to content at native resolution, removing the dead margin.

The figure now genuinely supports the sentence next to it: game is
visibly dominant, play/just/get are large, and love and good are the
only clearly affective terms - which is why the paper says only
Negative and Positive have sentiment-bearing top terms.

>>> PROFANITY - YOUR CALL, TWO FILES PROVIDED <<<
  The honest figure contains "fuck" (309 occurrences, the 6th most
  frequent term in your feature space, 182 of them in the Negative
  class) and "shit" (193). This is real data and it is substantively
  relevant: it is the evidence that Negative has the most distinctive
  vocabulary, which is exactly why Negative has the best F1 (0.528).
  I did not quietly censor your data. Both versions are in figures/:

    fig_wordcloud_v5.png         <- currently used, unmasked, faithful
    fig_wordcloud_v5_masked.png  <- same layout, f*** and s***

  To switch, change one line in main.tex (around line 223):
      \includegraphics[width=0.78\linewidth]{figures/fig_wordcloud_v5_masked.png}
  and if you do, add one clause to the caption:
      "... sized by corpus frequency; two profane terms are
       typographically masked."
  Masking with asterisks keeps the frequency and keeps the term
  identifiable, so it is defensible in a paper - it is not hiding data.
  For a course submission where the course teacher is a listed author,
  you may well prefer the masked one. Your decision, not mine.


------------------------------------------------------------------------
5. HOW v5 GETS TO 6 PAGES
------------------------------------------------------------------------
FIRST, THE MEASUREMENT. In your v4 PDF, page 7 has content in the LEFT
column only, running from y=54 to y=258. That is 204 pt of one column.
So exactly 204 pt had to be freed from pages 1-6 - no more, no less.
Everything below is sized against that number.

The key mechanic: a full-width float (figure* / table*) costs TWICE its
height in column-points, because it consumes both columns. So the two
things to attack were the tallest full-width floats, and I measured them
rather than guessing. They were nearly tied:

    Table I  (litreview)   207 pt full-width  = 414 pt of column
    Fig. 2   (EDA panels)  206 pt full-width  = 412 pt of column
    Fig. 3   (noise sweep) 250 pt single-column
    Table VI (per-fold CV)  96 pt full-width  = 192 pt of column
    Table III               185 pt   Table V  136 pt
    Table IV                125 pt   Table II 108 pt

THE EDITS, in column-equivalent points:

  -412  Fig. 2 was a full-width two-panel figure* (class distribution
        + word cloud). The class-distribution panel was pure
        duplication - all four counts are already in Table II and the
        1,514 / 30.26% figures are already in the sentence next to it.
        Deleted. No information lost.
  +172  Fig. 2 is now a single-column word cloud at 0.78\linewidth.
        Being single-column is the bigger win: LaTeX can set it beside
        its own paragraph instead of queueing for a page top.
   -54  Table I: \small -> \footnotesize, tabcolsep 6pt -> 4pt, and the
        p{} columns changed to a ragged-right column type. Justified
        text in a 2.2 cm column breaks badly and wastes a line per
        cell; ragged-right recovers it.
   -34  Table VI had NO size command at all - it was rendering at full
        10 pt while every other table was smaller. Now \footnotesize.
   -36  Tables II, III, IV, V: \small -> \footnotesize.
   +12  Fig. 1 rebuilt (see below); marginally taller after \resizebox.
   +19  Table I: the two corrected rows from part 3 are longer.
   +22  Abstract gained a sentence (see below) and Section II reworded.
  ----
  -271  NET, against a 204 pt requirement = 67 pt (a third of a column)
        of headroom.

On top of that, v4 had FOUR full-width floats competing for page tops
and v5 has three, which reduces float bunching in a way the arithmetic
above does not even count.

WHY \footnotesize AND NOT SMALLER. In a 10 pt IEEEtran document
\footnotesize is 8 pt, and 8 pt is IEEE's stated minimum for text
inside tables and figures. \scriptsize would be 7 pt, i.e. a format
violation. \footnotesize is the floor, and it is completely normal in
IEEE tables.

IF IT STILL COMES OUT AT 7 PAGES, the next lever is the bibliography.
IEEEtran prints "[Online]. Available: https://doi.org/..." for every
entry, which costs roughly one extra line each - about a third of a
column across 23 references. Deleting the url = {...} line from the
entries that also have a doi = {...} line recovers that. I did NOT do
it, because those links are the easiest way for your teacher to confirm
the references are real, and that seemed worth more than the space.

WHAT I DELIBERATELY DID NOT DO
  - I did not shrink \vspace around the section headings. That was
    suggested to me and I rejected it: IEEEtran's vertical spacing is
    part of the mandated format, conferences run IEEE PDF eXpress
    compliance checks on exactly this, and the whole trick buys maybe
    10-15 pt. Bad trade.
  - I did not drop the Kharde & Sonawane [7] citation. It is the survey
    that establishes NB/MaxEnt/SVM as the standard baselines, which is
    the justification for your entire model selection. Cutting a load-
    bearing citation to save two lines is not a good deal.
  - I did not shorten Ethical Considerations further. It is already
    down to two sentences (46 words). If your rubric does not require
    it, delete subsection III-G outright; nothing else breaks.


------------------------------------------------------------------------
6. OTHER v5 CHANGES
------------------------------------------------------------------------
(A) FIG. 1 SAID "SIX PHASES" AND DREW NINE BOXES
    Genuine inconsistency, correctly spotted. Rebuilt as six boxes
    labelled i) to vi), matching the sentence one-for-one. The three
    boxes that vanished were not content - they were the split, the
    metric list and the CV step, all of which now sit inside the phase
    they belong to. Caption also now states the one thing the diagram
    is really there to prove: noise is injected only after the split.

(B) GAUSSIAN NAIVE BAYES IS NOW DISCLOSED WHERE IT HAPPENS
    v4 admitted this only in the Limitations, which is late. It is now
    stated in Section III-E, where the classifiers are described, with
    a forward pointer to Section V. Verified against your actual saved
    model, not assumed: nb_bow$tables[["love"]] is a 4x2 [mean, sd]
    matrix and every predictor column is numeric, which is exactly how
    e1071::naiveBayes stores GAUSSIAN densities. For factor predictors
    it would store one column per level instead. So the claim is true.

(C) THE p = 0.061 TEST IS NOW NAMED
    v4 quoted p = 0.061 and p < 2.2e-16 without ever saying what test
    produced them. They are caret's "P-Value [Acc > NIR]" line, which
    is a ONE-SIDED EXACT BINOMIAL TEST of accuracy against the
    No-Information Rate. Named in Section III-F, where the metrics are
    defined - not in III-D where it was suggested, because III-D is
    the noise injection subsection and the baseline is not defined
    there yet.

(D) ABSTRACT WAS 145 WORDS, WHICH IS UNDER IEEE'S FLOOR
    IEEE's range is 150-250. v4 sat at 145, i.e. just outside, and
    nobody caught it. One sentence added, giving the actual takeaway
    the abstract was missing:
      "The practical implication is that for a pipeline of this kind
       the weighting scheme is a second-order decision, while the
       choice of classifier family is the first-order one."
    Now 177 words.

(E) SECTION IV-A REWRITTEN
    It referenced the deleted class-distribution panel, and it had to
    stop leaning on a figure that no longer exists. It now carries the
    30.26% baseline in prose, keeps the tweet-length medians, and
    points forward to Section IV-D for why Irrelevant and Neutral are
    the weak classes. Also fixed a sentence I had written and then
    checked: an earlier draft claimed only Negative has an affective
    vocabulary, but the Positive class's own top-5 terms include love
    (151 occurrences within that class) and good (117), so that was
    false. Corrected before shipping.

(F) LABELS AND HOUSEKEEPING
    Added \label{sec:results}, \label{sec:conclusion},
    \label{sec:errors} so the new cross-references resolve.
    Removed \usepackage{subcaption} (nothing needs it now that Fig. 2
    is one panel) and added \usepackage{array} for the ragged-right
    column type.

(G) STYLE PASS
    Checked mechanically for the things that make text read as
    machine-written: zero em-dashes, zero "moreover/furthermore/
    additionally" sentence openers, no "delve/leverage/underscore/
    pivotal/robust tapestry" vocabulary, spelling consistently British
    (-ise) throughout, and sentence length varying from 4 to 59 words
    with a standard deviation of 13.8. Flat, uniform sentence length is
    the strongest tell and this is not that.

WHAT I DID NOT CHANGE, ON PURPOSE
  Title (it is genuinely distinctive - a finding, not a topic label),
  the author block, the Conclusion and Limitations (honest and
  correctly scoped), and the Acknowledgment. The suggestion to make the
  Introduction state the research gap harder was declined: the gap is
  already stated in Introduction paragraph 2 ("classical machine-
  learning research rarely measures how much accuracy is lost...") and
  again in Section II paragraph 3 ("Whether classical, non-neural
  classifiers behave the same way... is the question addressed here").
  Saying it a third time in 6 pages is padding, not emphasis.


------------------------------------------------------------------------
7. REFERENCES - VERIFIED AGAINST CROSSREF THIS ROUND
------------------------------------------------------------------------
All 23 entries are cited, all 23 cited keys exist, no orphans either
way. The 2025 entries were the flagged hallucination risk, so they were
checked first. Every DOI below was resolved and the metadata compared
field by field.

 CONFIRMED EXACT (title, authors, journal, year, volume, issue, pages):
  R12 Zhang 2025, PLOS ONE 20(7):e0327347
      doi 10.1371/journal.pone.0327347 - real, sole author Li Zhang,
      published online 30 July 2025. Title matches exactly.
  R13 Al Sarayrah, Alkudah, Al-kharabsheh 2025, J. Computer Science
      21(8):1785-1794, doi 10.3844/jcssp.2025.1785.1794 - real, all
      three authors match, volume/issue/pages match.
  R22 Aliakbarzadeh, Flek, Karimi, arXiv:2501.08322, submitted
      14 January 2025 - real, title and all three authors match.
  R6  Gautam & Yadav 2014, IC3, pages 437-442 - confirmed (this was
      flagged as unverified in v4; it is fine).
  R11 Srikanth et al. 2024 - all seven authors confirmed, and the
      Crossref record gives pages 304-310, which were missing.

 TWO BIB FIXES MADE IN v5:
  - R10 first author was WRONG. The bib said "Qi, Yichen"; the paper's
    author is YUXING Qi. Corrected. (IEEEtran renders both as "Y. Qi",
    so the printed reference list looked fine either way - but the .bib
    was wrong and anyone checking it would have found it.)
  - R11 pages 304-310 added; and volume = {517} REMOVED. I could not
    confirm that LNICST volume number from Crossref, Springer, EUDL or
    the ISBN record. Rather than print an unverified number in a
    bibliography, the field is gone - the entry is still fully
    identifiable from booktitle + series + pages + DOI + year. If you
    can see the volume number on the book's series page, put it back.

 Relevance of every entry (unchanged from v4, nothing is padding):
 R1  Salton & Buckley 1988    TF-IDF weighting        -> Eq. (1). Core.
 R2  Cortes & Vapnik 1995     SVM                     -> your classifier
 R3  McCallum & Nigam 1998    NB event models         -> classifier, and
                                 the Gaussian/multinomial disclosure
 R4  Pang, Lee, Vaithy. 2002  ML sentiment classif.   -> foundation
 R5  Neethu & Rajasree 2013   Twitter sentiment ML    -> Table I
 R6  Gautam & Yadav 2014      Twitter BoW/TF-IDF+sem. -> Table I
 R7  Kharde & Sonawane 2016   Twitter SA survey       -> Table I
 R8  Belinkov & Bisk 2018     noise breaks neural MT  -> your noise
                                 method comes from here. Core.
 R9  Moradi & Samwald 2021    LM input perturbation   -> robustness
 R10 Qi & Shabrina 2023       lexicon vs ML on Twitter-> why ML-only
 R11 Srikanth et al. 2024     NB/LinearSVC/LR + TF-IDF-> Table I
 R12 Zhang 2025               TF-IDF+NB, news         -> Table I
 R13 Al Sarayrah et al. 2025  NB/SVM/BiLSTM           -> Table I
 R14 tm package               your preprocessing
 R15 Kaggle dataset           your data
 R16 Sokolova & Lapalme 2009  macro-averaging         -> Eq. (2)
 R17 Dietterich 1998          why no fold-wise t-test -> Section IV-E
 R18 Cohen 1960               Kappa                   -> Eq. (3)
 R19 Bohning 1992             multinomial logistic    -> your classifier
 R20 Kuhn 2008                caret                   -> your split, and
                                 confusionMatrix / No-Information Rate
 R21 Reusens et al. 2024      text-classif. benchmark -> Table I
 R22 Aliakbarzadeh et al 2025 LLM noise robustness    -> robustness
 R23 Venables & Ripley 2002   nnet / multinom()       -> your MLR


------------------------------------------------------------------------
8. FIGURES: USED vs SPARE   (updated for v6)
------------------------------------------------------------------------
USED
    (TikZ, inside main.tex)          -> Fig. 1  pipeline, six phases
    fig_wordcloud_v6.png             -> Fig. 2  word cloud, YOUR image,
                                                cropped (part 0.2)
    fig_e_noise_sweep.png            -> Fig. 3  noise severity sweep
    fig_d_clean_vs_noisy.png         -> Fig. 4  clean vs noisy, NEW in v6
    fig_cm_v6.png                    -> Fig. 5  confusion matrix heat map,
                                                NEW in v6
    fig_cv_v6.png                    -> Fig. 6  per-fold CV, NEW in v6

SPARE (in figures/, not referenced by main.tex)
    other word-cloud variants:
    fig_wordcloud_v5.png         unmasked word cloud, all 24 real terms
    fig_wordcloud_v5_masked.png  my asterisk-masked variant - part 4
    fig4_wordcloud.png           your original word cloud (the one with
                                 the silently dropped words - kept only
                                 for comparison; do not use it)
    superseded by the v6 re-renders:
    fig_g_cv_perfold.png         6.6 in wide, axis text falls under 5 pt
                                 in a single column - see part 0.4
    fig_confusion_matrix.png     carries its own title inside the image,
                                 which the caption already provides
    still cut, on purpose (part 0.3):
    fig_a_class_distribution.png four bars already in Table II
    fig_b_length_hist.png        tweet length, which IV-A says was not
    fig_c_length_by_class.png    used as a feature
    fig_f_bubble.png             both axes are columns of Table III

Each single-column figure at width=\linewidth costs roughly 190-230
col-pt, which is about a sixth of a page. See part 0.7 before adding a
fourth one.


------------------------------------------------------------------------
9. WHERE THE NUMBERS COME FROM  (nothing was invented)
------------------------------------------------------------------------
  Table I    related work    -> the 8 cited papers, re-verified, part 3
  Table II   dataset counts  -> Part 1 of your R script
  Table III  Acc/P/R/F1/Kappa-> data/table_overall_metrics.csv
  Table IV   confusion matrix-> data/cm_best_MLR_BoW_clean.csv
  Table V    per-class P/R/F1-> data/table_perclass_metrics.csv
  Table VI   per-fold CV     -> data/table_cv_perfold_wide.csv
  Fig. 2     word cloud      -> colSums(bow_matrix) from your .RData,
                                via mkwordcloud.R in this ZIP; the
                                shipped PNG is your own edit of it
  Fig. 3     noise sweep     -> sweep_summary (Part 3)
  Fig. 4     clean vs noisy  -> your R run, unaltered; every bar is a
                                cell of Table III
  Fig. 5     confusion matrix-> the 16 cells of Table IV, as literals in
                                mkfigs_v6.R
  Fig. 6     per-fold CV     -> the 30 cells of Table VI, as literals in
                                mkfigs_v6.R

  Tweet-length medians in IV-A were re-checked against data_sample:
  16 overall, and 16 / 17 / 17 / 14 by class. Correct as printed.

  p = 0.061 for TF-IDF+NB and p < 2.2e-16 for the SVMs are caret's
  "P-Value [Acc > NIR]" lines - a one-sided exact binomial test, now
  named in III-F. No p-value is quoted for MLR anywhere, because caret
  never printed one for it.

  No McNemar test and no paired t-test is reported, because you did not
  run them. Stability is argued from the repeated-trial SDs (max 1.1
  points) and the CV SDs (0.78-1.83), with Dietterich [17] cited for
  why a fold-wise paired t-test would be the wrong test at this size.


------------------------------------------------------------------------
10. BEFORE YOU SUBMIT   (updated for v6)
------------------------------------------------------------------------
 [ ] Recompile twice on Overleaf; confirm no [?] citations and no [?]
     figure references - v6 added three new \ref targets.
 [ ] CHECK THE PAGE COUNT FIRST. The target is 7. The first v6 build
     put reference [23] alone on page 8; Section V was shortened by
     80.5 pt against a 34.8 pt overflow, so page 8 should now be gone
     and the last column should end about four lines short. If page 8
     somehow survives, use the escape hatch at the end of part 0.7 -
     comment out ONE figure block, do not start shrinking fonts.
 [ ] Check the two corrected emails against your student IDs one more
     time: 23-55559-3 for Murad Hasan, 23-52252-2 for Atia Chowdhury.
 [ ] Look at Fig. 2. Confirm the cropped word cloud is not clipping any
     word at an edge, and that you are happy with the caption sentence
     about the two withheld terms (part 0.2).
 [ ] Look at Figs. 4, 5 and 6 at print size. All three are drawn at
     column width, so the text inside should be 8 pt or larger, which
     is IEEE's floor. Confirm visually.
 [ ] Read the three new paragraphs: end of IV-C, second paragraph of
     IV-D, second paragraph of IV-E. Each explains its figure.
 [ ] Read part 0.6. Two numeric claims changed in the abstract, IV-C and
     the conclusion. If you have quoted the old "1.4 points for the same
     classifier" line anywhere else - slides, report, presentation
     script - fix it there too.
 [ ] Look at Table I. It is \footnotesize with ragged-right columns; the
     spec measures 16.4 cm of columns plus 1.12 cm of separation =
     17.52 cm, inside IEEEtran's 18.13 cm full width, so it should not
     overflow. Confirm visually anyway.
 [ ] Look at Fig. 1. Six boxes in one row, \resizebox'd to full width.
     Confirm the text inside is still legible at print size.
 [ ] Look at Eq. (2) - the two-line aligned block - and confirm it does
     not overrun the column.
 [ ] Confirm your rubric does not require the "Ethical Standards of
     Engineering Practice" heading verbatim.
 [ ] Read Section II paragraph 2 once. That is where the two corrected
     claims from part 3 live.
========================================================================
