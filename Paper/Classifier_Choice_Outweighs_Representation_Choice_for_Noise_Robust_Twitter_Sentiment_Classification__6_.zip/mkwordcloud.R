# ----------------------------------------------------------------------
# Regenerates Fig. 2 (the word cloud) for the IEEE paper, v5.
#
# Run this from the paper folder (the one containing main.tex), with your
# .RData sitting next to it, or edit RDATA below to point at it.
#
# Why this script exists instead of the wordcloud() call in analysis.R:
# wordcloud() SILENTLY DROPS words it cannot place and only emits a
# warning. The original figure dropped "game" (785) and "just" (450),
# the 1st and 3rd most frequent terms, while the paper's text names
# "game" as the most frequent term in three of the four classes. The
# figure contradicted the text. This version guarantees that cannot
# happen, and it builds the cloud from the 177-term feature space the
# classifiers actually consume rather than from the raw corpus.
# ----------------------------------------------------------------------

suppressPackageStartupMessages({library(wordcloud); library(RColorBrewer)})

RDATA <- ".RData"                 # <- edit if your .RData is elsewhere
DIR   <- "figures/"               # output folder, relative to this script

e <- new.env(); load(RDATA, envir = e)
freq <- sort(colSums(get("bow_matrix", envir = e)), decreasing = TRUE)

# tm::removePunctuation does not strip the Unicode right single quote
# (U+2019), so four "terms" in the 177-word vocabulary are apostrophe
# fragments. Drop tokens that are not alphabetic words; they are
# artefacts, not terms, and they only confuse the plot. The paper's
# "177 terms" is still correct: that IS the vocabulary the models were
# trained on, artefacts included.
keep <- grepl("^[a-z]+$", names(freq))
cat("dropped non-word tokens:", paste(names(freq)[!keep], collapse = " "), "\n")
freq <- freq[keep]

MAXW <- 24

# Two variants with an identical layout (same seed): the faithful one,
# and one with the two profane terms typographically masked. Masking
# keeps the frequency and keeps the term identifiable, so the figure
# still reports the data honestly. See README part 4.
mask <- c(fuck = "f***", shit = "s***")

render <- function(labels, out) {
  # wordcloud() packs words flush against their neighbours, so two
  # horizontally adjacent terms read as one ("justget"). Padding each
  # label with spaces makes the layout engine reserve a gap, because it
  # measures the padded string.
  labels <- paste0(" ", labels, " ")
  for (top in c(3.2, 3.0, 2.8, 2.6, 2.4)) {
    warns <- character(0)
    set.seed(42)                  # fixed layout, reproducible across variants
    png(out, width = 4.0, height = 3.8, units = "in", res = 300, bg = "white")
    par(mar = c(0, 0, 0, 0))
    # Capture the drop warning instead of letting it scroll past, and
    # step the font scale down until nothing is dropped at all.
    withCallingHandlers(
      wordcloud(labels, as.numeric(freq),
                max.words    = MAXW,
                scale        = c(top, 1.25),
                random.order = FALSE,
                rot.per      = 0,
                colors       = brewer.pal(8, "Dark2")),
      warning = function(w) { warns <<- c(warns, conditionMessage(w)); invokeRestart("muffleWarning") }
    )
    dev.off()
    if (length(warns) == 0) {
      cat(sprintf("  %s: all %d words placed at scale top = %.1f\n",
                  basename(out), MAXW, top))
      return(invisible(TRUE))
    }
  }
  cat("  WARNING:", basename(out), "still dropping words at the smallest scale\n")
  invisible(FALSE)
}

lab_plain <- names(freq)
lab_mask  <- ifelse(names(freq) %in% names(mask), mask[names(freq)], names(freq))

render(lab_plain, paste0(DIR, "fig_wordcloud_v5.png"))
render(lab_mask,  paste0(DIR, "fig_wordcloud_v5_masked.png"))

cat("\nthe", MAXW, "most frequent terms of the 177-term BoW feature space:\n")
print(head(freq, MAXW))

# NOTE: the PNGs shipped in figures/ were additionally cropped to their
# content to remove about 25% dead white margin. If you re-run this
# script the output will have that margin back, which just means Fig. 2
# renders slightly smaller inside the same 0.78\linewidth box.
